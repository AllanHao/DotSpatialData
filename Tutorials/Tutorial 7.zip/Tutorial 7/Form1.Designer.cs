﻿namespace Tutorial_7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.spatialDockManager1 = new DotSpatial.Controls.SpatialDockManager();
            this.gbShapeAttribute = new System.Windows.Forms.GroupBox();
            this.btnDisplayLabel = new System.Windows.Forms.Button();
            this.cmbFiledName = new System.Windows.Forms.ComboBox();
            this.lblFieldName = new System.Windows.Forms.Label();
            this.gbCustomAttribute = new System.Windows.Forms.GroupBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtCustomAttribute = new System.Windows.Forms.TextBox();
            this.lblLabelName = new System.Windows.Forms.Label();
            this.gbCustom = new System.Windows.Forms.GroupBox();
            this.btnsetColor = new System.Windows.Forms.Button();
            this.btnsetFont = new System.Windows.Forms.Button();
            this.map1 = new DotSpatial.Controls.Map();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mapOptionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zoomINToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zoomOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zoomToMaxExtentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.defaultToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorDialog2 = new System.Windows.Forms.ColorDialog();
            ((System.ComponentModel.ISupportInitialize)(this.spatialDockManager1)).BeginInit();
            this.spatialDockManager1.Panel1.SuspendLayout();
            this.spatialDockManager1.Panel2.SuspendLayout();
            this.spatialDockManager1.SuspendLayout();
            this.gbShapeAttribute.SuspendLayout();
            this.gbCustomAttribute.SuspendLayout();
            this.gbCustom.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // spatialDockManager1
            // 
            this.spatialDockManager1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.spatialDockManager1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spatialDockManager1.Location = new System.Drawing.Point(0, 24);
            this.spatialDockManager1.Name = "spatialDockManager1";
            // 
            // spatialDockManager1.Panel1
            // 
            this.spatialDockManager1.Panel1.Controls.Add(this.gbShapeAttribute);
            this.spatialDockManager1.Panel1.Controls.Add(this.gbCustomAttribute);
            this.spatialDockManager1.Panel1.Controls.Add(this.gbCustom);
            // 
            // spatialDockManager1.Panel2
            // 
            this.spatialDockManager1.Panel2.Controls.Add(this.map1);
            this.spatialDockManager1.Size = new System.Drawing.Size(547, 478);
            this.spatialDockManager1.SplitterDistance = 182;
            this.spatialDockManager1.TabControl1 = null;
            this.spatialDockManager1.TabControl2 = null;
            this.spatialDockManager1.TabIndex = 0;
            // 
            // gbShapeAttribute
            // 
            this.gbShapeAttribute.Controls.Add(this.btnDisplayLabel);
            this.gbShapeAttribute.Controls.Add(this.cmbFiledName);
            this.gbShapeAttribute.Controls.Add(this.lblFieldName);
            this.gbShapeAttribute.Location = new System.Drawing.Point(11, 140);
            this.gbShapeAttribute.Name = "gbShapeAttribute";
            this.gbShapeAttribute.Size = new System.Drawing.Size(148, 100);
            this.gbShapeAttribute.TabIndex = 2;
            this.gbShapeAttribute.TabStop = false;
            this.gbShapeAttribute.Text = "Display label from Attribute table";
            // 
            // btnDisplayLabel
            // 
            this.btnDisplayLabel.Location = new System.Drawing.Point(6, 63);
            this.btnDisplayLabel.Name = "btnDisplayLabel";
            this.btnDisplayLabel.Size = new System.Drawing.Size(136, 31);
            this.btnDisplayLabel.TabIndex = 2;
            this.btnDisplayLabel.Text = "Display Labels";
            this.btnDisplayLabel.UseVisualStyleBackColor = true;
            this.btnDisplayLabel.Click += new System.EventHandler(this.btnDisplayLabel_Click);
            // 
            // cmbFiledName
            // 
            this.cmbFiledName.FormattingEnabled = true;
            this.cmbFiledName.Location = new System.Drawing.Point(55, 33);
            this.cmbFiledName.Name = "cmbFiledName";
            this.cmbFiledName.Size = new System.Drawing.Size(87, 21);
            this.cmbFiledName.TabIndex = 1;
            // 
            // lblFieldName
            // 
            this.lblFieldName.AutoSize = true;
            this.lblFieldName.Location = new System.Drawing.Point(9, 36);
            this.lblFieldName.Name = "lblFieldName";
            this.lblFieldName.Size = new System.Drawing.Size(34, 13);
            this.lblFieldName.TabIndex = 0;
            this.lblFieldName.Text = "Fields";
            // 
            // gbCustomAttribute
            // 
            this.gbCustomAttribute.Controls.Add(this.btnDelete);
            this.gbCustomAttribute.Controls.Add(this.btnAdd);
            this.gbCustomAttribute.Controls.Add(this.btnSave);
            this.gbCustomAttribute.Controls.Add(this.txtCustomAttribute);
            this.gbCustomAttribute.Controls.Add(this.lblLabelName);
            this.gbCustomAttribute.Location = new System.Drawing.Point(11, 257);
            this.gbCustomAttribute.Name = "gbCustomAttribute";
            this.gbCustomAttribute.Size = new System.Drawing.Size(148, 179);
            this.gbCustomAttribute.TabIndex = 2;
            this.gbCustomAttribute.TabStop = false;
            this.gbCustomAttribute.Text = "Custom Attributes for existing shape file";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(6, 142);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(136, 31);
            this.btnDelete.TabIndex = 5;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(6, 68);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(136, 31);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(6, 105);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(136, 31);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtCustomAttribute
            // 
            this.txtCustomAttribute.Location = new System.Drawing.Point(71, 35);
            this.txtCustomAttribute.Name = "txtCustomAttribute";
            this.txtCustomAttribute.Size = new System.Drawing.Size(69, 20);
            this.txtCustomAttribute.TabIndex = 4;
            this.txtCustomAttribute.TextChanged += new System.EventHandler(this.txtCustomAttribute_TextChanged);
            // 
            // lblLabelName
            // 
            this.lblLabelName.AutoSize = true;
            this.lblLabelName.Location = new System.Drawing.Point(3, 38);
            this.lblLabelName.Name = "lblLabelName";
            this.lblLabelName.Size = new System.Drawing.Size(64, 13);
            this.lblLabelName.TabIndex = 3;
            this.lblLabelName.Text = "Label Name";
            // 
            // gbCustom
            // 
            this.gbCustom.Controls.Add(this.btnsetColor);
            this.gbCustom.Controls.Add(this.btnsetFont);
            this.gbCustom.Location = new System.Drawing.Point(11, 15);
            this.gbCustom.Name = "gbCustom";
            this.gbCustom.Size = new System.Drawing.Size(148, 100);
            this.gbCustom.TabIndex = 1;
            this.gbCustom.TabStop = false;
            this.gbCustom.Text = "Set the label properties";
            // 
            // btnsetColor
            // 
            this.btnsetColor.Location = new System.Drawing.Point(6, 59);
            this.btnsetColor.Name = "btnsetColor";
            this.btnsetColor.Size = new System.Drawing.Size(136, 31);
            this.btnsetColor.TabIndex = 1;
            this.btnsetColor.Text = "Set Color";
            this.btnsetColor.UseVisualStyleBackColor = true;
            this.btnsetColor.Click += new System.EventHandler(this.btnsetColor_Click);
            // 
            // btnsetFont
            // 
            this.btnsetFont.Location = new System.Drawing.Point(6, 22);
            this.btnsetFont.Name = "btnsetFont";
            this.btnsetFont.Size = new System.Drawing.Size(136, 31);
            this.btnsetFont.TabIndex = 0;
            this.btnsetFont.Text = "Set Font Style and Size";
            this.btnsetFont.UseVisualStyleBackColor = true;
            this.btnsetFont.Click += new System.EventHandler(this.btnsetFont_Click);
            // 
            // map1
            // 
            this.map1.AllowDrop = true;
            this.map1.BackColor = System.Drawing.Color.White;
            this.map1.CollectAfterDraw = false;
            this.map1.CollisionDetection = false;
            this.map1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.map1.ExtendBuffer = false;
            this.map1.FunctionMode = DotSpatial.Controls.FunctionMode.None;
            this.map1.IsBusy = false;
            this.map1.IsZoomedToMaxExtent = false;
            this.map1.Legend = null;
            this.map1.Location = new System.Drawing.Point(0, 0);
            this.map1.Name = "map1";
            this.map1.ProgressHandler = null;
            this.map1.ProjectionModeDefine = DotSpatial.Controls.ActionMode.Prompt;
            this.map1.ProjectionModeReproject = DotSpatial.Controls.ActionMode.Prompt;
            this.map1.RedrawLayersWhileResizing = false;
            this.map1.SelectionEnabled = true;
            this.map1.Size = new System.Drawing.Size(359, 476);
            this.map1.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.mapOptionsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(547, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadToolStripMenuItem,
            this.clearToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.loadToolStripMenuItem.Text = "Load";
            this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.clearToolStripMenuItem.Text = "Clear";
            this.clearToolStripMenuItem.Click += new System.EventHandler(this.clearToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // mapOptionsToolStripMenuItem
            // 
            this.mapOptionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zoomINToolStripMenuItem,
            this.zoomOutToolStripMenuItem,
            this.zoomToMaxExtentToolStripMenuItem,
            this.panToolStripMenuItem,
            this.defaultToolStripMenuItem});
            this.mapOptionsToolStripMenuItem.Name = "mapOptionsToolStripMenuItem";
            this.mapOptionsToolStripMenuItem.Size = new System.Drawing.Size(88, 20);
            this.mapOptionsToolStripMenuItem.Text = "Map Options";
            // 
            // zoomINToolStripMenuItem
            // 
            this.zoomINToolStripMenuItem.Name = "zoomINToolStripMenuItem";
            this.zoomINToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.zoomINToolStripMenuItem.Text = "Zoom In";
            this.zoomINToolStripMenuItem.Click += new System.EventHandler(this.zoomINToolStripMenuItem_Click);
            // 
            // zoomOutToolStripMenuItem
            // 
            this.zoomOutToolStripMenuItem.Name = "zoomOutToolStripMenuItem";
            this.zoomOutToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.zoomOutToolStripMenuItem.Text = "Zoom Out";
            this.zoomOutToolStripMenuItem.Click += new System.EventHandler(this.zoomOutToolStripMenuItem_Click);
            // 
            // zoomToMaxExtentToolStripMenuItem
            // 
            this.zoomToMaxExtentToolStripMenuItem.Name = "zoomToMaxExtentToolStripMenuItem";
            this.zoomToMaxExtentToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.zoomToMaxExtentToolStripMenuItem.Text = "Zoom to MaxExtent";
            this.zoomToMaxExtentToolStripMenuItem.Click += new System.EventHandler(this.zoomToMaxExtentToolStripMenuItem_Click);
            // 
            // panToolStripMenuItem
            // 
            this.panToolStripMenuItem.Name = "panToolStripMenuItem";
            this.panToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.panToolStripMenuItem.Text = "Pan";
            this.panToolStripMenuItem.Click += new System.EventHandler(this.panToolStripMenuItem_Click);
            // 
            // defaultToolStripMenuItem
            // 
            this.defaultToolStripMenuItem.Name = "defaultToolStripMenuItem";
            this.defaultToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.defaultToolStripMenuItem.Text = "Default";
            this.defaultToolStripMenuItem.Click += new System.EventHandler(this.defaultToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(547, 502);
            this.Controls.Add(this.spatialDockManager1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form1";
            this.Text = "Tutorial 7";
            this.spatialDockManager1.Panel1.ResumeLayout(false);
            this.spatialDockManager1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spatialDockManager1)).EndInit();
            this.spatialDockManager1.ResumeLayout(false);
            this.gbShapeAttribute.ResumeLayout(false);
            this.gbShapeAttribute.PerformLayout();
            this.gbCustomAttribute.ResumeLayout(false);
            this.gbCustomAttribute.PerformLayout();
            this.gbCustom.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DotSpatial.Controls.SpatialDockManager spatialDockManager1;
        private System.Windows.Forms.GroupBox gbShapeAttribute;
        private System.Windows.Forms.Button btnDisplayLabel;
        private System.Windows.Forms.ComboBox cmbFiledName;
        private System.Windows.Forms.Label lblFieldName;
        private System.Windows.Forms.GroupBox gbCustomAttribute;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtCustomAttribute;
        private System.Windows.Forms.Label lblLabelName;
        private System.Windows.Forms.GroupBox gbCustom;
        private System.Windows.Forms.Button btnsetColor;
        private System.Windows.Forms.Button btnsetFont;
        private DotSpatial.Controls.Map map1;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mapOptionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zoomINToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zoomOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zoomToMaxExtentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem panToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem defaultToolStripMenuItem;
        private System.Windows.Forms.ColorDialog colorDialog2;
    }
}

