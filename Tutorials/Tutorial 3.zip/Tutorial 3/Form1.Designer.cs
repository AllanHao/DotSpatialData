﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtElevation = new System.Windows.Forms.TextBox();
            this.chbRasterValue = new System.Windows.Forms.CheckBox();
            this.lblRasterValue = new System.Windows.Forms.Label();
            this.lblElevation = new System.Windows.Forms.Label();
            this.btnReclassify = new System.Windows.Forms.Button();
            this.btnMultiplyRaster = new System.Windows.Forms.Button();
            this.btnChangeColor = new System.Windows.Forms.Button();
            this.btnHillshade = new System.Windows.Forms.Button();
            this.btnLoadRaster = new System.Windows.Forms.Button();
            this.sdmLegendMap = new DotSpatial.Controls.SpatialDockManager();
            this.Legend1 = new DotSpatial.Controls.Legend();
            this.spatialStatusStrip1 = new DotSpatial.Controls.SpatialStatusStrip();
            this.map1 = new DotSpatial.Controls.Map();
            this.appManager1 = new DotSpatial.Controls.AppManager();
            this.spatialHeaderControl1 = new DotSpatial.Controls.SpatialHeaderControl();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sdmLegendMap)).BeginInit();
            this.sdmLegendMap.Panel1.SuspendLayout();
            this.sdmLegendMap.Panel2.SuspendLayout();
            this.sdmLegendMap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spatialHeaderControl1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtElevation);
            this.panel1.Controls.Add(this.chbRasterValue);
            this.panel1.Controls.Add(this.lblRasterValue);
            this.panel1.Controls.Add(this.lblElevation);
            this.panel1.Controls.Add(this.btnReclassify);
            this.panel1.Controls.Add(this.btnMultiplyRaster);
            this.panel1.Controls.Add(this.btnChangeColor);
            this.panel1.Controls.Add(this.btnHillshade);
            this.panel1.Controls.Add(this.btnLoadRaster);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(648, 105);
            this.panel1.TabIndex = 0;
            // 
            // txtElevation
            // 
            this.txtElevation.Location = new System.Drawing.Point(477, 36);
            this.txtElevation.Name = "txtElevation";
            this.txtElevation.Size = new System.Drawing.Size(95, 20);
            this.txtElevation.TabIndex = 8;
            this.txtElevation.Text = "3000";
            // 
            // chbRasterValue
            // 
            this.chbRasterValue.AutoSize = true;
            this.chbRasterValue.Location = new System.Drawing.Point(233, 83);
            this.chbRasterValue.Name = "chbRasterValue";
            this.chbRasterValue.Size = new System.Drawing.Size(161, 17);
            this.chbRasterValue.TabIndex = 7;
            this.chbRasterValue.Text = "Raster value at clicked point";
            this.chbRasterValue.UseVisualStyleBackColor = true;
            this.chbRasterValue.CheckedChanged += new System.EventHandler(this.chbRasterValue_CheckedChanged);
            // 
            // lblRasterValue
            // 
            this.lblRasterValue.AutoSize = true;
            this.lblRasterValue.Location = new System.Drawing.Point(230, 58);
            this.lblRasterValue.Name = "lblRasterValue";
            this.lblRasterValue.Size = new System.Drawing.Size(106, 13);
            this.lblRasterValue.TabIndex = 6;
            this.lblRasterValue.Text = "Row: Column: Value:";
            // 
            // lblElevation
            // 
            this.lblElevation.AutoSize = true;
            this.lblElevation.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblElevation.Location = new System.Drawing.Point(420, 39);
            this.lblElevation.Name = "lblElevation";
            this.lblElevation.Size = new System.Drawing.Size(51, 13);
            this.lblElevation.TabIndex = 5;
            this.lblElevation.Text = "Elevation";
            this.lblElevation.Click += new System.EventHandler(this.lblElevation_Click);
            // 
            // btnReclassify
            // 
            this.btnReclassify.Location = new System.Drawing.Point(339, 34);
            this.btnReclassify.Name = "btnReclassify";
            this.btnReclassify.Size = new System.Drawing.Size(75, 23);
            this.btnReclassify.TabIndex = 4;
            this.btnReclassify.Text = "&Reclassify Raster";
            this.btnReclassify.UseVisualStyleBackColor = true;
            this.btnReclassify.Click += new System.EventHandler(this.btnReclassify_Click);
            // 
            // btnMultiplyRaster
            // 
            this.btnMultiplyRaster.Location = new System.Drawing.Point(339, 3);
            this.btnMultiplyRaster.Name = "btnMultiplyRaster";
            this.btnMultiplyRaster.Size = new System.Drawing.Size(75, 23);
            this.btnMultiplyRaster.TabIndex = 3;
            this.btnMultiplyRaster.Text = "&Multiply Raster";
            this.btnMultiplyRaster.UseVisualStyleBackColor = true;
            this.btnMultiplyRaster.Click += new System.EventHandler(this.btnMultiplyRaster_Click);
            // 
            // btnChangeColor
            // 
            this.btnChangeColor.Location = new System.Drawing.Point(258, 4);
            this.btnChangeColor.Name = "btnChangeColor";
            this.btnChangeColor.Size = new System.Drawing.Size(75, 23);
            this.btnChangeColor.TabIndex = 2;
            this.btnChangeColor.Text = "Change &Color";
            this.btnChangeColor.UseVisualStyleBackColor = true;
            this.btnChangeColor.Click += new System.EventHandler(this.btnChangeColor_Click);
            // 
            // btnHillshade
            // 
            this.btnHillshade.Location = new System.Drawing.Point(258, 33);
            this.btnHillshade.Name = "btnHillshade";
            this.btnHillshade.Size = new System.Drawing.Size(75, 23);
            this.btnHillshade.TabIndex = 1;
            this.btnHillshade.Text = "&Hillshade";
            this.btnHillshade.UseVisualStyleBackColor = true;
            this.btnHillshade.Click += new System.EventHandler(this.btnHillshade_Click);
            // 
            // btnLoadRaster
            // 
            this.btnLoadRaster.Location = new System.Drawing.Point(23, 4);
            this.btnLoadRaster.Name = "btnLoadRaster";
            this.btnLoadRaster.Size = new System.Drawing.Size(123, 70);
            this.btnLoadRaster.TabIndex = 0;
            this.btnLoadRaster.Text = "&Load Raster";
            this.btnLoadRaster.UseVisualStyleBackColor = true;
            this.btnLoadRaster.Click += new System.EventHandler(this.btnLoadRaster_Click);
            // 
            // sdmLegendMap
            // 
            this.sdmLegendMap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sdmLegendMap.Location = new System.Drawing.Point(0, 105);
            this.sdmLegendMap.Name = "sdmLegendMap";
            // 
            // sdmLegendMap.Panel1
            // 
            this.sdmLegendMap.Panel1.Controls.Add(this.Legend1);
            // 
            // sdmLegendMap.Panel2
            // 
            this.sdmLegendMap.Panel2.Controls.Add(this.spatialStatusStrip1);
            this.sdmLegendMap.Panel2.Controls.Add(this.map1);
            this.sdmLegendMap.Size = new System.Drawing.Size(648, 297);
            this.sdmLegendMap.SplitterDistance = 213;
            this.sdmLegendMap.TabControl1 = null;
            this.sdmLegendMap.TabControl2 = null;
            this.sdmLegendMap.TabIndex = 1;
            // 
            // Legend1
            // 
            this.Legend1.BackColor = System.Drawing.Color.White;
            this.Legend1.ControlRectangle = new System.Drawing.Rectangle(0, 0, 213, 297);
            this.Legend1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Legend1.DocumentRectangle = new System.Drawing.Rectangle(0, 0, 54, 193);
            this.Legend1.HorizontalScrollEnabled = true;
            this.Legend1.Indentation = 30;
            this.Legend1.IsInitialized = false;
            this.Legend1.Location = new System.Drawing.Point(0, 0);
            this.Legend1.MinimumSize = new System.Drawing.Size(5, 5);
            this.Legend1.Name = "Legend1";
            this.Legend1.ProgressHandler = null;
            this.Legend1.ResetOnResize = false;
            this.Legend1.SelectionFontColor = System.Drawing.Color.Black;
            this.Legend1.SelectionHighlight = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(238)))), ((int)(((byte)(252)))));
            this.Legend1.Size = new System.Drawing.Size(213, 297);
            this.Legend1.TabIndex = 0;
            this.Legend1.Text = "legend1";
            this.Legend1.VerticalScrollEnabled = true;
            // 
            // spatialStatusStrip1
            // 
            this.spatialStatusStrip1.Location = new System.Drawing.Point(0, 275);
            this.spatialStatusStrip1.Name = "spatialStatusStrip1";
            this.spatialStatusStrip1.ProgressBar = null;
            this.spatialStatusStrip1.ProgressLabel = null;
            this.spatialStatusStrip1.Size = new System.Drawing.Size(431, 22);
            this.spatialStatusStrip1.TabIndex = 1;
            this.spatialStatusStrip1.Text = "spatialStatusStrip1";
            // 
            // map1
            // 
            this.map1.AllowDrop = true;
            this.map1.BackColor = System.Drawing.Color.White;
            this.map1.CollectAfterDraw = false;
            this.map1.CollisionDetection = false;
            this.map1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.map1.ExtendBuffer = false;
            this.map1.FunctionMode = DotSpatial.Controls.FunctionMode.None;
            this.map1.IsBusy = false;
            this.map1.IsZoomedToMaxExtent = false;
            this.map1.Legend = this.Legend1;
            this.map1.Location = new System.Drawing.Point(0, 0);
            this.map1.Name = "map1";
            this.map1.ProgressHandler = null;
            this.map1.ProjectionModeDefine = DotSpatial.Controls.ActionMode.Prompt;
            this.map1.ProjectionModeReproject = DotSpatial.Controls.ActionMode.Prompt;
            this.map1.RedrawLayersWhileResizing = false;
            this.map1.SelectionEnabled = true;
            this.map1.Size = new System.Drawing.Size(431, 297);
            this.map1.TabIndex = 0;
            this.map1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.map1_MouseUp);
            // 
            // appManager1
            // 
            this.appManager1.Directories = ((System.Collections.Generic.List<string>)(resources.GetObject("appManager1.Directories")));
            this.appManager1.DockManager = this.sdmLegendMap;
            this.appManager1.HeaderControl = this.spatialHeaderControl1;
            this.appManager1.Legend = this.Legend1;
            this.appManager1.Map = this.map1;
            this.appManager1.ProgressHandler = this.spatialStatusStrip1;
            this.appManager1.ShowExtensionsDialogMode = DotSpatial.Controls.ShowExtensionsDialogMode.Default;
            // 
            // spatialHeaderControl1
            // 
            this.spatialHeaderControl1.ApplicationManager = null;
            this.spatialHeaderControl1.MenuStrip = null;
            this.spatialHeaderControl1.ToolbarsContainer = null;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(648, 402);
            this.Controls.Add(this.sdmLegendMap);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Tutorial 3";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.sdmLegendMap.Panel1.ResumeLayout(false);
            this.sdmLegendMap.Panel2.ResumeLayout(false);
            this.sdmLegendMap.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sdmLegendMap)).EndInit();
            this.sdmLegendMap.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spatialHeaderControl1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnReclassify;
        private System.Windows.Forms.Button btnMultiplyRaster;
        private System.Windows.Forms.Button btnChangeColor;
        private System.Windows.Forms.Button btnHillshade;
        private System.Windows.Forms.Button btnLoadRaster;
        private DotSpatial.Controls.SpatialDockManager sdmLegendMap;
        private System.Windows.Forms.Label lblRasterValue;
        private System.Windows.Forms.Label lblElevation;
        private System.Windows.Forms.TextBox txtElevation;
        private System.Windows.Forms.CheckBox chbRasterValue;
        private DotSpatial.Controls.Legend Legend1;
        private DotSpatial.Controls.Map map1;
        private DotSpatial.Controls.AppManager appManager1;
        private DotSpatial.Controls.SpatialHeaderControl spatialHeaderControl1;
        private DotSpatial.Controls.SpatialStatusStrip spatialStatusStrip1;

    }
}

