﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.OleDb;
using DotSpatial.Data;
using DotSpatial.Topology;
using DotSpatial.Projections;
using DotSpatial.Controls;
using DotSpatial.Extensions;
using DotSpatial.Controls.Header;
using System.Windows.Forms;

namespace DotSpatial_8_Working_With_Plugins
{
    class MainCode
    {
        public static FeatureSet OpenExcelFile()
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "Excel Files|*.xlsx";
            if (openDialog.ShowDialog() == DialogResult.OK)
            {
                DataTable excelTable = ConvertExcelFileToDataTable(openDialog.FileName);
                return ConvertDataTableToFeatureSet(excelTable);
            }
            return null;
        }

        private static DataTable ConvertExcelFileToDataTable(string excelFileName)
        {
            string connectionString =
                String.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Excel 12.0 Xml;HDR=YES;IMEX=1\"", excelFileName);

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                string query = "SELECT * FROM [Sheet1$]";
                connection.Open();
                OleDbCommand command = new OleDbCommand(query, connection);
                OleDbDataAdapter adapter = new OleDbDataAdapter(command);

                DataTable excelTable = new DataTable();
                adapter.Fill(excelTable);
                return excelTable;
            }
        }

        private static FeatureSet ConvertDataTableToFeatureSet(DataTable excelTable)
        {
            // See if table has the lat, long columns
            if (excelTable.Columns.Contains("lat") & excelTable.Columns.Contains("long"))
            {
                FeatureSet fs = new FeatureSet(FeatureType.Point);
                fs.Projection = KnownCoordinateSystems.Geographic.World.WGS1984;

                // Set columns of attribute table
                fs.DataTable = excelTable.Clone();

                foreach (DataRow excelRow in excelTable.Rows)
                {
                    double lat = Double.Parse(excelRow["lat"].ToString());
                    double lon = Double.Parse(excelRow["long"].ToString());

                    // Add the point to the FeatureSet
                    Coordinate coord = new Coordinate(lon, lat);
                    Point point = new Point(coord);
                    IFeature feature = fs.AddFeature(point);

                    // Bring over all of the data as attribute data.
                    for (int i = 0; i <= excelTable.Columns.Count - 1; i++)
                    {
                        feature.DataRow[i] = excelRow[i];
                    }
                }
                return fs;
            }
            else
            {
                MessageBox.Show("The excel table must have lat and long columns.");
                return null;
            }
        }
    }
}
