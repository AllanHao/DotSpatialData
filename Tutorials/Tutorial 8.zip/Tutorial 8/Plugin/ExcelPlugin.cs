﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using DotSpatial.Data;
using DotSpatial.Topology;
using DotSpatial.Projections;
using DotSpatial.Controls;
using DotSpatial.Extensions;
using DotSpatial.Controls.Header;
using System.Windows.Forms;

namespace DotSpatial_8_Working_With_Plugins
{
    public class ExcelPlugin : Extension
    {
        public override void Activate()
        {
            App.HeaderControl.Add(new SimpleActionItem("Import Data From Excel", button_Click));
            base.Activate();
        }

        public override void Deactivate()
        {
            App.HeaderControl.RemoveAll();
            base.Deactivate();
        }

        private void button_Click(object sender, EventArgs e)
        {
            var featureSet = MainCode.OpenExcelFile();

            if (featureSet != null)
            {
                //add feature set to map
                var layer = App.Map.Layers.Add(featureSet);
                layer.LegendText = "Points From Excel";
            }
        }
    }
}
