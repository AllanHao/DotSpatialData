﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DotSpatial.Controls.Docking;
using DevExpress.XtraBars;


namespace DotSpatial_Main_Sample
{
    public partial class Form1 : Form
    {
        [Export("Shell",typeof(ContainerControl))]
       private static ContainerControl Shell;

        public Form1()
        {
            InitializeComponent();
            if (DesignMode) return;
            Shell = this;
            appManager1.LoadExtensions();
            this.appManager1.DockManager.Add(new DockablePanel("kMap", "Map", map1, DockStyle.Fill));
            new DotSpatial.Controls.DefaultMenuBars(appManager1).Initialize(appManager1.HeaderControl);


        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
