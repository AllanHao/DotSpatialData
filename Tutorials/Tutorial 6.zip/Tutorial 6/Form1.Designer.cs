﻿namespace Tutorial_6
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.appManager1 = new DotSpatial.Controls.AppManager();
            this.sdmLegendMap = new DotSpatial.Controls.SpatialDockManager();
            this.legend1 = new DotSpatial.Controls.Legend();
            this.map1 = new DotSpatial.Controls.Map();
            this.spatialHeaderControl1 = new DotSpatial.Controls.SpatialHeaderControl();
            this.spatialStatusStrip1 = new DotSpatial.Controls.SpatialStatusStrip();
            this.pnlOperations = new System.Windows.Forms.Panel();
            this.lbltitle = new System.Windows.Forms.Label();
            this.btnViewElevation = new System.Windows.Forms.Button();
            this.btnDrawPath = new System.Windows.Forms.Button();
            this.btnLoadDEM = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.sdmLegendMap)).BeginInit();
            this.sdmLegendMap.Panel1.SuspendLayout();
            this.sdmLegendMap.Panel2.SuspendLayout();
            this.sdmLegendMap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spatialHeaderControl1)).BeginInit();
            this.pnlOperations.SuspendLayout();
            this.SuspendLayout();
            // 
            // appManager1
            // 
            this.appManager1.Directories = ((System.Collections.Generic.List<string>)(resources.GetObject("appManager1.Directories")));
            this.appManager1.DockManager = this.sdmLegendMap;
            this.appManager1.HeaderControl = this.spatialHeaderControl1;
            this.appManager1.Legend = null;
            this.appManager1.Map = null;
            this.appManager1.ProgressHandler = this.spatialStatusStrip1;
            this.appManager1.ShowExtensionsDialogMode = DotSpatial.Controls.ShowExtensionsDialogMode.Default;
            // 
            // sdmLegendMap
            // 
            this.sdmLegendMap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sdmLegendMap.Location = new System.Drawing.Point(0, 95);
            this.sdmLegendMap.Name = "sdmLegendMap";
            // 
            // sdmLegendMap.Panel1
            // 
            this.sdmLegendMap.Panel1.Controls.Add(this.legend1);
            // 
            // sdmLegendMap.Panel2
            // 
            this.sdmLegendMap.Panel2.Controls.Add(this.map1);
            this.sdmLegendMap.Size = new System.Drawing.Size(718, 401);
            this.sdmLegendMap.SplitterDistance = 239;
            this.sdmLegendMap.TabControl1 = null;
            this.sdmLegendMap.TabControl2 = null;
            this.sdmLegendMap.TabIndex = 5;
            // 
            // legend1
            // 
            this.legend1.BackColor = System.Drawing.Color.White;
            this.legend1.ControlRectangle = new System.Drawing.Rectangle(0, 0, 239, 401);
            this.legend1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.legend1.DocumentRectangle = new System.Drawing.Rectangle(0, 0, 176, 177);
            this.legend1.HorizontalScrollEnabled = true;
            this.legend1.Indentation = 30;
            this.legend1.IsInitialized = false;
            this.legend1.Location = new System.Drawing.Point(0, 0);
            this.legend1.MinimumSize = new System.Drawing.Size(5, 5);
            this.legend1.Name = "legend1";
            this.legend1.ProgressHandler = null;
            this.legend1.ResetOnResize = false;
            this.legend1.SelectionFontColor = System.Drawing.Color.Black;
            this.legend1.SelectionHighlight = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(238)))), ((int)(((byte)(252)))));
            this.legend1.Size = new System.Drawing.Size(239, 401);
            this.legend1.TabIndex = 0;
            this.legend1.Text = "legend1";
            this.legend1.VerticalScrollEnabled = true;
            // 
            // map1
            // 
            this.map1.AllowDrop = true;
            this.map1.BackColor = System.Drawing.Color.White;
            this.map1.CollectAfterDraw = false;
            this.map1.CollisionDetection = false;
            this.map1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.map1.ExtendBuffer = false;
            this.map1.FunctionMode = DotSpatial.Controls.FunctionMode.None;
            this.map1.IsBusy = false;
            this.map1.IsZoomedToMaxExtent = false;
            this.map1.Legend = this.legend1;
            this.map1.Location = new System.Drawing.Point(0, 0);
            this.map1.Name = "map1";
            this.map1.ProgressHandler = null;
            this.map1.ProjectionModeDefine = DotSpatial.Controls.ActionMode.Prompt;
            this.map1.ProjectionModeReproject = DotSpatial.Controls.ActionMode.Prompt;
            this.map1.RedrawLayersWhileResizing = false;
            this.map1.SelectionEnabled = true;
            this.map1.Size = new System.Drawing.Size(475, 401);
            this.map1.TabIndex = 0;
            this.map1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.map1_MouseDown);
            // 
            // spatialHeaderControl1
            // 
            this.spatialHeaderControl1.ApplicationManager = null;
            this.spatialHeaderControl1.MenuStrip = null;
            this.spatialHeaderControl1.ToolbarsContainer = null;
            // 
            // spatialStatusStrip1
            // 
            this.spatialStatusStrip1.Location = new System.Drawing.Point(0, 496);
            this.spatialStatusStrip1.Name = "spatialStatusStrip1";
            this.spatialStatusStrip1.ProgressBar = null;
            this.spatialStatusStrip1.ProgressLabel = null;
            this.spatialStatusStrip1.Size = new System.Drawing.Size(718, 22);
            this.spatialStatusStrip1.TabIndex = 3;
            this.spatialStatusStrip1.Text = "spatialStatusStrip1";
            // 
            // pnlOperations
            // 
            this.pnlOperations.Controls.Add(this.lbltitle);
            this.pnlOperations.Controls.Add(this.btnViewElevation);
            this.pnlOperations.Controls.Add(this.btnDrawPath);
            this.pnlOperations.Controls.Add(this.btnLoadDEM);
            this.pnlOperations.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlOperations.Location = new System.Drawing.Point(0, 0);
            this.pnlOperations.Name = "pnlOperations";
            this.pnlOperations.Size = new System.Drawing.Size(718, 95);
            this.pnlOperations.TabIndex = 4;
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitle.ForeColor = System.Drawing.Color.DarkRed;
            this.lbltitle.Location = new System.Drawing.Point(291, 16);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(165, 24);
            this.lbltitle.TabIndex = 3;
            this.lbltitle.Text = "Hiking Path Finder";
            // 
            // btnViewElevation
            // 
            this.btnViewElevation.Location = new System.Drawing.Point(575, 52);
            this.btnViewElevation.Name = "btnViewElevation";
            this.btnViewElevation.Size = new System.Drawing.Size(98, 37);
            this.btnViewElevation.TabIndex = 2;
            this.btnViewElevation.Text = "&View Elevation";
            this.btnViewElevation.UseVisualStyleBackColor = true;
            this.btnViewElevation.Click += new System.EventHandler(this.btnViewElevation_Click);
            // 
            // btnDrawPath
            // 
            this.btnDrawPath.Location = new System.Drawing.Point(166, 52);
            this.btnDrawPath.Name = "btnDrawPath";
            this.btnDrawPath.Size = new System.Drawing.Size(98, 37);
            this.btnDrawPath.TabIndex = 1;
            this.btnDrawPath.Text = "&Draw Hiking Path";
            this.btnDrawPath.UseVisualStyleBackColor = true;
            this.btnDrawPath.Click += new System.EventHandler(this.btnDrawPath_Click);
            // 
            // btnLoadDEM
            // 
            this.btnLoadDEM.Location = new System.Drawing.Point(37, 52);
            this.btnLoadDEM.Name = "btnLoadDEM";
            this.btnLoadDEM.Size = new System.Drawing.Size(98, 37);
            this.btnLoadDEM.TabIndex = 0;
            this.btnLoadDEM.Text = "&Load DEM";
            this.btnLoadDEM.UseVisualStyleBackColor = true;
            this.btnLoadDEM.Click += new System.EventHandler(this.btnLoadDEM_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(718, 518);
            this.Controls.Add(this.sdmLegendMap);
            this.Controls.Add(this.pnlOperations);
            this.Controls.Add(this.spatialStatusStrip1);
            this.Name = "frmMain";
            this.Text = "Tutorial 6";
            this.sdmLegendMap.Panel1.ResumeLayout(false);
            this.sdmLegendMap.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sdmLegendMap)).EndInit();
            this.sdmLegendMap.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spatialHeaderControl1)).EndInit();
            this.pnlOperations.ResumeLayout(false);
            this.pnlOperations.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DotSpatial.Controls.AppManager appManager1;
        private DotSpatial.Controls.SpatialHeaderControl spatialHeaderControl1;
        private DotSpatial.Controls.SpatialStatusStrip spatialStatusStrip1;
        private DotSpatial.Controls.SpatialDockManager sdmLegendMap;
        private DotSpatial.Controls.Legend legend1;
        private DotSpatial.Controls.Map map1;
        private System.Windows.Forms.Panel pnlOperations;
        private System.Windows.Forms.Label lbltitle;
        private System.Windows.Forms.Button btnViewElevation;
        private System.Windows.Forms.Button btnDrawPath;
        private System.Windows.Forms.Button btnLoadDEM;
    }
}

